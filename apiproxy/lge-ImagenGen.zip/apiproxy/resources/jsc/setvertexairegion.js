var envname = context.getVariable("environment.name");
var regionname = context.getVariable("system.region.name");

// if this is dev, set us-central1 as vertexai.region.name
if( envname == "dev" || envname == "eval"){
    context.setVariable("vertexai.region.name", "us-central1");
}else{
    context.setVariable("vertexai.region.name", regionname);
}