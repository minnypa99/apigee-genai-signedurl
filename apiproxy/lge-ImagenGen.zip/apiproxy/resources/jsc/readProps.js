var envname = context.getVariable("environment.name");
var regionname = context.getVariable("system.region.name");

// env - dev, qa, prod
// region - asia-northeast3, us-east4, europe-west4

var cloudrun_audience = context.getVariable("propertyset." + envname + ".audience_" + regionname);
var cloudrun_lburl = context.getVariable("propertyset." + envname + ".lburl_" + regionname);

context.setVariable("cloudrun.audience", cloudrun_audience);

context.setVariable("cloudrun.lburl", cloudrun_lburl);