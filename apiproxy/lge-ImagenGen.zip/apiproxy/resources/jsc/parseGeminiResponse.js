var response = context.getVariable("geminiResponse.content"); 
var responseJson = JSON.parse(response);

var text = responseJson.candidates[0].content.parts[0].text;


context.setVariable("text",text);

var imagen_prompt = text.substring(text.indexOf('<')+1, text.indexOf('>'));
context.setVariable("imagen.prompt",imagen_prompt);