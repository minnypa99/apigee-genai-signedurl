var prompt = context.getVariable("imagen.prompt") || context.getVariable("user.prompt");
context.setVariable("imagen.prompt", prompt);

context.setVariable("target.copy.pathsuffix", false);
context.setVariable("target.copy.queryparams", false);

var requestJSON = JSON.parse(context.getVariable("request.content"));
delete requestJSON["customparams"];

// requestJSON["instances"][0]["prompt"] = prompt;

context.setVariable("request.content", JSON.stringify(requestJSON));