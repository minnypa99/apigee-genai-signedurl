 var resp = {};

var imagenResp = context.getVariable("response.content");
var imagenRespJson = JSON.parse(imagenResp);


//var kst = crypto.dateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ",'GMT+9', context.getVariable("client.received.start.timestamp"));
//context.setVariable("imagen.kstimestamp", kst);

var predictions = imagenRespJson.predictions;
context.setVariable("imagen.predictions",JSON.stringify(predictions) );

var bucketname = context.getVariable("signedurl.bucket");
var gcsUri_prefix = "gs://" + bucketname + "/";
var gcsUri_prefix_len = gcsUri_prefix.length;

//  gs://cb-imagen-signedurl-bucket/plain/2024-11-08/1731069407508/sample_0.png

for(var i in predictions) {
    predictions[i].filename = (predictions[i].gcsUri).substring(gcsUri_prefix_len);
}
    
context.setVariable("signedurl.predictions", JSON.stringify(predictions) );

